using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public enum GameState { Playing, GameOver, Won }

// Tracks score, keys, clues and game state, and builds the HUD (Canvas + Text) at runtime.
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public int keysRequired = 1;
    public int totalClues = 2;

    public GameState State { get; private set; } = GameState.Playing;
    public bool IsPlaying { get { return State == GameState.Playing; } }
    public int Score { get; private set; }
    public int Keys { get; private set; }
    public int Clues { get; private set; }

    private Text scoreText, messageText, statusText, hintText;
    private Image overlay;
    private Font font;
    private Coroutine messageRoutine;

    void Awake()
    {
        Instance = this;
        Time.timeScale = 1f;
        BuildUI();
    }

    void Start()
    {
        RefreshHUD();
        ShowMessage("Find the key to unlock the temple door", 5f);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
            Restart();
        else if (!IsPlaying && Input.GetKeyDown(KeyCode.Return))
            Restart();
    }

    // ---------- Game events ----------

    public void AddScore(int points)
    {
        if (!IsPlaying) return;
        Score += points;
        RefreshHUD();
    }

    public void AddKey()
    {
        if (!IsPlaying) return;
        Keys++;
        RefreshHUD();
        ShowMessage("Key collected! Return to the temple door.", 4f);
    }

    public void AddClue(string text)
    {
        if (!IsPlaying) return;
        Clues++;
        RefreshHUD();
        ShowMessage(string.IsNullOrEmpty(text) ? "Clue found!" : text, 5f);
    }

    public void GameOver(string reason)
    {
        if (State != GameState.Playing) return;
        State = GameState.GameOver;
        overlay.gameObject.SetActive(true);
        statusText.color = new Color(1f, 0.25f, 0.2f);
        statusText.text = "GAME OVER\n<size=36>" + reason + "\nPress R to restart</size>";
        messageText.text = "";
    }

    public void Victory(int bonus)
    {
        if (State != GameState.Playing) return;
        Score += bonus;
        State = GameState.Won;
        RefreshHUD();
        overlay.gameObject.SetActive(true);
        statusText.color = new Color(1f, 0.85f, 0.2f);
        statusText.text = "TREASURE FOUND!\n<size=36>Final score: " + Score + "\nPress R to play again</size>";
        messageText.text = "";
    }

    public void ShowMessage(string text, float seconds)
    {
        if (messageText == null) return;
        if (messageRoutine != null) StopCoroutine(messageRoutine);
        messageRoutine = StartCoroutine(MessageRoutine(text, seconds));
    }

    public void Restart()
    {
        Scene s = SceneManager.GetActiveScene();
        SceneManager.LoadScene(s.buildIndex >= 0 ? s.buildIndex : 0);
    }

    private IEnumerator MessageRoutine(string text, float seconds)
    {
        messageText.text = text;
        yield return new WaitForSeconds(seconds);
        if (IsPlaying) messageText.text = "";
    }

    private void RefreshHUD()
    {
        scoreText.text = "Score: " + Score +
                         "\nKeys: " + Keys + "/" + keysRequired +
                         "\nClues: " + Clues + "/" + totalClues;
    }

    // ---------- HUD construction ----------

    private Font GetFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    private void BuildUI()
    {
        font = GetFont();

        GameObject canvasGO = new GameObject("HUD Canvas");
        canvasGO.transform.SetParent(transform, false);
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        // Dark overlay for Game Over / Victory
        GameObject ov = new GameObject("Overlay", typeof(RectTransform));
        ov.transform.SetParent(canvasGO.transform, false);
        overlay = ov.AddComponent<Image>();
        overlay.color = new Color(0f, 0f, 0f, 0.55f);
        overlay.raycastTarget = false;
        RectTransform r = overlay.rectTransform;
        r.anchorMin = Vector2.zero;
        r.anchorMax = Vector2.one;
        r.offsetMin = r.offsetMax = Vector2.zero;
        ov.SetActive(false);

        scoreText = MakeText(canvasGO.transform, "ScoreText", new Vector2(0f, 1f), new Vector2(0f, 1f),
                             new Vector2(30f, -25f), new Vector2(600f, 200f), 38, TextAnchor.UpperLeft);
        messageText = MakeText(canvasGO.transform, "MessageText", new Vector2(0.5f, 0.85f), new Vector2(0.5f, 0.5f),
                               Vector2.zero, new Vector2(1500f, 100f), 44, TextAnchor.MiddleCenter);
        statusText = MakeText(canvasGO.transform, "StatusText", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                              Vector2.zero, new Vector2(1500f, 400f), 96, TextAnchor.MiddleCenter);
        hintText = MakeText(canvasGO.transform, "HintText", new Vector2(0f, 0f), new Vector2(0f, 0f),
                            new Vector2(30f, 25f), new Vector2(1200f, 60f), 28, TextAnchor.LowerLeft);

        messageText.color = Color.white;
        hintText.color = new Color(1f, 1f, 1f, 0.8f);
        hintText.text = "WASD / Arrows: Move    Space: Jump    R: Restart";
        scoreText.color = new Color(1f, 0.92f, 0.5f);
    }

    private Text MakeText(Transform parent, string name, Vector2 anchor, Vector2 pivot,
                          Vector2 pos, Vector2 size, int fontSize, TextAnchor align)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.font = font;
        t.fontSize = fontSize;
        t.alignment = align;
        t.color = Color.white;
        t.supportRichText = true;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        RectTransform r = t.rectTransform;
        r.anchorMin = r.anchorMax = anchor;
        r.pivot = pivot;
        r.anchoredPosition = pos;
        r.sizeDelta = size;
        Outline o = go.AddComponent<Outline>();
        o.effectColor = Color.black;
        o.effectDistance = new Vector2(2f, -2f);
        return t;
    }
}
